<?php

/**
 * This is a simple file to include for testing the RouteCollection class.
 */

$routes->add('testing', 'TestController::index');
